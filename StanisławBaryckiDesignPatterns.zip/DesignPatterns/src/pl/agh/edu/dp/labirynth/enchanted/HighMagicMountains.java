package pl.agh.edu.dp.labirynth.enchanted;

import pl.agh.edu.dp.labirynth.Wall;

public class HighMagicMountains extends Wall {
    @Override
    public void Enter() {
        System.out.println("Mountains are to high to climb");
    }
}
