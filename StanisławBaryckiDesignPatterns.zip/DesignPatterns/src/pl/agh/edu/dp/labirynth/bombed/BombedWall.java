package pl.agh.edu.dp.labirynth.bombed;

import pl.agh.edu.dp.labirynth.Wall;

public class BombedWall extends Wall {
    @Override
    public void Enter() {
        System.out.println("BOOOOOM!!!");
    }
}
